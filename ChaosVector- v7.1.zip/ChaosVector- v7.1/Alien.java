import greenfoot.GreenfootImage;
import greenfoot.Actor;
import greenfoot.*;
/**
 * Write a description of class Alien here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Alien extends Enemies
{   
    private int speed = 4; // mvt speed of the boss
    private int chargeSpeed = 6; //mvt when charging towards the player
    private int chargeCoolDown = 0; //charge CD;
    
    private int health, maxHealth;
    
    public static int killCount;
    
    public Alien()
    {
        GreenfootImage image = getImage();  
        image.scale(130, 100);
        image.rotate(-90);
        setImage(image);
        
        maxHealth = 100;
        health = maxHealth;
    }
    
    public void setMaxHealth(int maxHp)
    {
        maxHealth = maxHp;
    }
    
    public void setSpeed(int speed)
    {
        this.speed = speed;
    }
    
    public void setChargeSpeed(int cspeed)
    {
        chargeSpeed = cspeed;
    }
    
    /**
     * Act - do whatever the Alien wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        FollowPlayer();
        ShootPlayer();
        ChargePlayer();
    }
    private Spaceship getSpaceship()
    {
        if(getWorld().getObjects(Spaceship.class).isEmpty())
            return null;
            return getWorld().getObjects(Spaceship.class).get(0);
    }
    
    public void FollowPlayer()
    {
        if(!getWorld().getObjects(Spaceship.class).isEmpty()){
            Spaceship spaceship = getWorld().getObjects(Spaceship.class).get(0);
            
            turnTowards(spaceship.getX(), spaceship.getY());
            move(speed);
        }
    }
    
    public void ShootPlayer()//shoot at player at random time
    {
        if(Greenfoot.getRandomNumber(30) == 0){
            if (getWorld() == null)
            return;
            AlienBullet a = new AlienBullet();
            getWorld().addObject(a, getX(), getY());
            
            Spaceship spaceship = getSpaceship();
            if(spaceship!=null)
                a.turnTowards(spaceship.getX(), spaceship.getY());
                
            GreenfootSound bullet = new GreenfootSound("alienBullet.mp3");
            bullet.setVolume(30); //volume
            bullet.play();
        }
    }
    
    private void ChargePlayer(){
        if(chargeCoolDown> 0){ //CD reset
            move(chargeSpeed);
            chargeCoolDown--;
            return;
        }
        
        if(Greenfoot.getRandomNumber(600)==0) //charge rate
        {
            Spaceship spaceship = getSpaceship();
            if(spaceship == null)
            return;
            turnTowards(spaceship.getX(), spaceship.getY());
            chargeCoolDown = 25;
        }
    }
    
    public void takeDamage(int damage)
    {
        health -= damage;
        
        if(health <=0)
        {
            killCount++;

            if(getWorld()!=null)
            {
                                
                
                getWorld().removeObject(this);
            }
                
                return;
        }
    }
    public int getHealth()
    {
        return health;
    }
    public double getStatus()
    {
        return (double)health/maxHealth; //stay as double
        
    }

    public void setHealth(int health)
    {
        this.health = health;
    }
    
}
