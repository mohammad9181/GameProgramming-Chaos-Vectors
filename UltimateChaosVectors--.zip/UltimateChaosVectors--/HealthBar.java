import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class HealthBar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HealthBar extends Actor
{
    private int width, height;
    private Spaceship mySpaceship;
    
    public HealthBar(int width, int height, Spaceship mySpaceship)
    {
        this.width = width;
        this.height = height;
        this.mySpaceship = mySpaceship;
    }
    
    public int getWidth()
    {
        return width;
    }
    
    public int getHeight()
    {
        return height;
    }
    
    /**
     * Act - do whatever the HealthBar wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
        draw();
    }
    
    public void draw()
    {
        GreenfootImage myImage = new GreenfootImage( width, height);
        //lost health
        myImage.setColor(Color.RED);
        myImage.fillRect(0, 0,width, height);
        // Draw remaining health
        int healthPercentage = (int)(mySpaceship.getStatus() * width);
        myImage.setColor(Color.GREEN);
        myImage.fillRect( 0, 0, healthPercentage, height);
        
        setImage(myImage);
    }

}