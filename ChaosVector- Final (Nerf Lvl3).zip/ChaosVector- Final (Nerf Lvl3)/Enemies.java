import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Enemies here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public abstract class Enemies extends Actor
{
    /**
     * Act - do whatever the Enemies wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
        if(isGameOver()){
            transitionToGameOver();
        }
    }
    
    public boolean isGameOver()
    {
        World world = getWorld();
        if(world.getObjects(Spaceship.class).isEmpty())
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public void transitionToGameOver()
    {
        World gameOver = new GameOver();
        Greenfoot.setWorld(gameOver);
        
    }
    

}
    

