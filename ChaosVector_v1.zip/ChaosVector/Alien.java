import greenfoot.GreenfootImage;
import greenfoot.Actor;

/**
 * Write a description of class Alien here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Alien extends Actor
{
    public Alien()
    {
        GreenfootImage image = getImage();  
        image.scale(180, 80);
        setImage(image);
        
        
    }
    /**
     * Act - do whatever the Alien wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        
        VerticalMove();
    }
    
    public void VerticalMove()
    {
        
    }
}
