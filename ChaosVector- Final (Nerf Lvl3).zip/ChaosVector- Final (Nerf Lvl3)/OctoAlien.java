import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import greenfoot.GreenfootImage;
import greenfoot.Actor;
/**
 * Write a description of class OctoAlien here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class OctoAlien extends Enemies
{
    private GreenfootImage[] frames = {
        new GreenfootImage("frame1.gif"),
        new GreenfootImage("frame2.gif"),
        new GreenfootImage("frame3.gif"),
        new GreenfootImage("frame4.gif"),
        new GreenfootImage("frame5.gif"),
        new GreenfootImage("frame6.gif"),
        new GreenfootImage("frame7.gif"),
        new GreenfootImage("frame8.gif"),
        new GreenfootImage("frame9.gif"),
        new GreenfootImage("frame10.gif")
    };
    
    private GreenfootImage[] expolodeFrames = {
        new GreenfootImage("Explosion1.png"),
        new GreenfootImage("Explosion2.png"),
        new GreenfootImage("Explosion3.png"),
        new GreenfootImage("Explosion4.png"),
        new GreenfootImage("Explosion5.png"),
        new GreenfootImage("Explosion6.png"),
    };
    
    private int explodeframe = 0;
    private int deathTimer = 0;
    
    private int frame = 0;
    private int timer = 0;

    private boolean bulletPhase = false;
    private int bulletTimer = 0;
    
    // Movement
    private int speed = 2;
    private int direction = 1;

    // Laser firing
    private int laserTimer = 0;
    private final int LASER_INTERVAL = 600;   // ~10 seconds at 60 fps
    private final int WARNING_DURATION = 60;  // 1 second warning
    private final int LASER_DURATION = 120;   // 2 seconds laser
    private boolean warningActive = false;
    private boolean laserActive = false;
    private int laserLife = 0;
    private Actor laser;   // reference to current laser
    
    private int health, maxHealth;
    
    public boolean isDead = false;
    
    
    
    public OctoAlien()
    {
        
        isDead = false;
        maxHealth = 4000;
        health = maxHealth;
        
        if(isDead == false)
        {
            for (int i = 0; i < frames.length; i++) {
                frames[i].scale(150, 150);
            }
            setImage(frames[0]);
        }
        else
        {
            for (int i = 0; i < expolodeFrames.length; i++) {
                    expolodeFrames[i].scale(150, 150);
            }
            
            setImage(expolodeFrames[0]);
        }
        
        
        
        
    }
    
    public void act()
    {
        
        if (getWorld() == null) 
        {
            return;
        }

        if (isDead) {
            animateDeath();
            return; // Don't run anything else
        }

        animateIdle();
        moveSideToSide();
        handleLaserAttack();

        if (getWorld() == null) return; // Check again in case removed during animation

        Spaceship ship = (Spaceship)getOneIntersectingObject(Spaceship.class);
        if (ship != null) {
            ship.takeDamage(5);
        }
    }
    
    public void setMaxHealth(int maxHp)
    {
        maxHealth = maxHp;
    }
    
    public void animateDeath() {
        
        if(getWorld()!=null)
        {
            deathTimer++;
            if (deathTimer % 10 == 0 && explodeframe < expolodeFrames.length) {
                setImage(expolodeFrames[explodeframe]);
                explodeframe++;
            }
            if (explodeframe >= expolodeFrames.length) {
            
                getWorld().removeObject(this);
            
            }
        }
        
    }
    
    private void animateIdle() {
        timer++;
        if (timer % 10 == 0) {
            frame = (frame + 1) % frames.length;
            setImage(frames[frame]);
        }
    }
    
    private void moveSideToSide() {
        setLocation(getX() + speed * direction, getY());
        if (getX() <= 50 || getX() >= getWorld().getWidth() - 50) {
            direction *= -1;
        }
    }
    
    private void handleLaserAttack() {
        laserTimer++;
        
        if (!warningActive && laserTimer >= LASER_INTERVAL - WARNING_DURATION) {
            showWarning();
            warningActive = true;
        }

        if (!laserActive && laserTimer >= LASER_INTERVAL) {
            shootLaser();
            laserActive = true;
            laserLife = LASER_DURATION;
            laserTimer = 0;
            warningActive = false;
        }

        // Manage laser lifetime
        if (laserActive) {
            laserLife--;
            if (laserLife <= 0) {
                if (laser != null && laser.getWorld() != null) {
                    getWorld().removeObject(laser);
                }
                laserActive = false;
            }
        }

        // Handle bullet spewing
        if (bulletPhase) {
            bulletTimer--;
            if (bulletTimer % 9 == 0) { // spawn every 15 ticks (~0.25s)
                OctoBullet bullet = new OctoBullet();
                getWorld().addObject(bullet, getX(), getY() + 0);
            }
            if (bulletTimer <= 0) {
                bulletPhase = false;
            }
        }
    }
    
    private void showWarning() {
        // Simple warning: flash boss red
        GreenfootImage img = new GreenfootImage(frames[frame]);
        img.setColor(Color.RED);
        img.drawRect(0, 0, img.getWidth()-1, img.getHeight()-1);
        setImage(img);
    }
    
    private void shootLaser() {
        laser = new Laser(this);
        getWorld().addObject(laser, getX(), getY() + 200);

        // Start bullet phase
        bulletPhase = true;
        bulletTimer = 300; // 5 seconds
    }
    
    public int getHealth()
    {
        return health;
    }
    
    public double getStatus()
    {
        return (double)health/maxHealth; //stay as double
        
    }

    public void setHealth(int health)
    {
        this.health = health;
    }
    
    public void takeDamage(int damage)
    {
        health -= damage;
        
        if(health <=0 && !isDead)
        {

            if(getWorld()!=null)
            {
                die();
            }
                
            
        }
    }
    
    public void die() {
        
        explodeframe = 0;
        deathTimer = 0;
        isDead = true;
    }
    
}
