import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Stage1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Stage1 extends Buttons
{
    
    public void Stage1()
    {
        GreenfootImage image = getImage();  
        image.scale(100, 50);
        setImage(image);
        World current = getWorld();
        ((Levels) current).stopMusic();  
    }
    /**
     * Act - do whatever the Stage1 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
        checkMouse();
        //checkClick(new Level1());
        if (Greenfoot.mouseClicked(this)) {
            World current = getWorld();
            if (current instanceof Levels) {
                ((Levels) current).stopMusic();
            } 
            
            
                //current.stopMusic();             // stop Levels BGM
                Greenfoot.setWorld(new Level1());
           }
           
           

    }
}
