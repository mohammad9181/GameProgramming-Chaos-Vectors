import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class TheEnd here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TheEnd extends World
{
    private GreenfootSound backgroundMusic = new GreenfootSound("duet.mp3");
    /**
     * Constructor for objects of class TheEnd.
     * 
     */
    public TheEnd()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(500, 270, 1); 
        prepare();
    }
    public void started()
    {
        backgroundMusic.playLoop();
    }
    
    public void stopped()
    {
        backgroundMusic.pause();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Exit exit = new Exit();
        addObject(exit,244,172);
        exit.setLocation(239,181);
        exit.setLocation(241,176);
    }
}
