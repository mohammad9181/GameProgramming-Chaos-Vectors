import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class OctoAlienBullet here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class OctoBullet extends Actor {
    private int dx;
    private int dy;

    public OctoBullet() {
        dx = Greenfoot.getRandomNumber(5) - 3; // range -3 to +3
        dy = Greenfoot.getRandomNumber(5) - 3;
        if (dx == 0 && dy == 0) dy = 1; // avoid standing still
    }

    public void act() {
        setLocation(getX() + dx, getY() + dy);

        // Remove if off screen
        if (getX() < 0 || getX() > getWorld().getWidth() ||
            getY() < 0 || getY() > getWorld().getHeight()) {
            getWorld().removeObject(this);
        }
        
        Spaceship ship = (Spaceship)getOneIntersectingObject(Spaceship.class);
        if (ship != null) {
            ship.takeDamage(40);
            getWorld().removeObject(this);
            return;
        }
        
        if (isAtEdge()) {
            getWorld().removeObject(this);
        }
        

    }
    

}
