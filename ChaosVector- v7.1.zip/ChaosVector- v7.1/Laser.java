import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Laser here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Laser extends Actor {
    private OctoAlien followTarget;
    
    private int life = 120; // lasts ~2 seconds at 60 fps
    private int alpha = 255; // full opacity

    private int speed = 2;
    private int direction = 1;
    public Laser(OctoAlien followTarget) {
        GreenfootImage image = getImage();  
        image.scale(350, 100);
        setRotation(90);
        this.followTarget = followTarget;
    }

    public void act() {
        if (followTarget != null && followTarget.getWorld() != null) {
            setLocation(followTarget.getX(), followTarget.getY() + 150);
        }
        
        life--;
        if (life > 0) {
            // Gradually reduce transparency
            alpha = (int)(255 * (life / 120.0));
            getImage().setTransparency(alpha);
        } else {
            getWorld().removeObject(this);
        }
        
        
        Spaceship ship = (Spaceship)getOneIntersectingObject(Spaceship.class);
        if (ship != null) 
        {
            ship.takeDamage(15); // 
        }
    }

}
