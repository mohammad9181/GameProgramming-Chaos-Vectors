import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class AlienBullet here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class AlienBullet extends Actor
{
    private int speed = 5;
    /**
     * Act - do whatever the AlienBullet wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        GreenfootImage image = getImage();  
        image.scale(35, 15);
        setImage(image);
         
        
        
        if(getWorld()== null)return;
        move(speed);
        
        if(isAtEdge()) getWorld().removeObject(this);
        if(getWorld()== null)return;
        if(getWorld()== null)return;
        
        Spaceship ship = (Spaceship)getOneIntersectingObject(Spaceship.class);
        if (ship != null) {
        ship.takeDamage(15); // 
        
        if(getWorld()!=null)
            getWorld().removeObject(this);
        return; // 
        }
    }
}
