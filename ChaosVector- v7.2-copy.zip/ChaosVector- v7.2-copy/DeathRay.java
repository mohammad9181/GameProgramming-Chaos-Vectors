import greenfoot.*;

public class DeathRay extends Actor {
    private FinalBoss owner;   // reference to boss
    private int life = 180;    // total lifetime (~3 seconds at 60 fps)
    private int alpha = 0;     // start transparent
    private boolean active = false; // whether it can damage
    private int warningTime = 60;   // 1 second warning
    private int activeTime = 60;    // 1 second fully active
    private int fadeTime = 60;      // 1 second fade out

    public DeathRay(FinalBoss owner)
    {
        this.owner = owner;
        setImage(new GreenfootImage("DeathRayLaser.png")); // your laser asset
        getImage().setTransparency(alpha); // start invisible
        getImage().scale(650, 200);
    }

    public void act() {
        // Follow boss position

        life--;

        if (life > activeTime + fadeTime) {
            // Warning phase: fade in but harmless
            int elapsed = warningTime - life;
            alpha = (int)(255 * (1 - (life - (activeTime + fadeTime)) / (double)warningTime));
            getImage().setTransparency(alpha);
        } else if (life > fadeTime) {
            // Active phase: fully visible and damaging
            active = true;
            getImage().setTransparency(255);

            // Damage player if intersecting
            Spaceship ship = (Spaceship)getOneIntersectingObject(Spaceship.class);
            if (ship != null) {
                ship.takeDamage(20);
            }
        } else if (life > 0) {
            // Fade out phase
            alpha = (int)(255 * (life / (double)fadeTime));
            getImage().setTransparency(alpha);
        } else {
            // End of life
            if (getWorld() != null) {
                getWorld().removeObject(this);
            }
        }
    }
}
