import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Level3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Level3 extends World
{
    private int maxHealthPotion = 1;
    private int maxStrenghtPotion = 1;
    
    private GreenfootSound backgroundMusic = new GreenfootSound("abond.mp3");
    /**
     * Constructor for objects of class Level3.
     * 
     */
    public Level3()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        
        spawnBoss();
         
        prepare();
    }
    
    public void started()
    {
        backgroundMusic.playLoop();
    }
    
    public void stopped()
    {
        backgroundMusic.pause();
    }
    
    public void act()
    {
        if (Greenfoot.getRandomNumber(850) < 1) { // small chance
                spawnHealthPotion();
            }
        if (Greenfoot.getRandomNumber(800) < 1) { // small chance
                spawnStrenghtPotion();
            }
    }
        public void spawnBoss()
    {
        
        FinalBoss boss = new FinalBoss();
        addObject(boss, 100, 100);
            
            //alien2.setMaxHealth(3500);
            //alien2.setHealth(3500);
            
        BossHp hp = new BossHp(200, 20, boss);
        addObject(hp, 500, 100);
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Spaceship spaceship = new Spaceship();
        addObject(spaceship,293,304);
        
        HealthBar healthBar = new HealthBar(100,10,spaceship);
        addObject(healthBar, healthBar.getWidth()/2, healthBar.getHeight()/2);
    }
    
    private void spawnHealthPotion()
    {
        HealthPotion h = new HealthPotion();
        int x = Greenfoot.getRandomNumber(getWidth()); // random horizontal
        int y = 0; // top of the world
        addObject(h, x, y);
    }
    
    private void spawnStrenghtPotion()
    {
        StrengthPotion s = new StrengthPotion();
        int x = Greenfoot.getRandomNumber(getWidth()); // random horizontal
        int y = 0; // top of the world
        addObject(s, x, y);
    }
}
    

