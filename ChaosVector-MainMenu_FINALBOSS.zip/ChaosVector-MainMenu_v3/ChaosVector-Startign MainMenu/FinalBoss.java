import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FinalBoss here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FinalBoss extends Actor
{
    /**
     * Act - do whatever the FinalBoss wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    private GreenfootImage[] frames = {
        new GreenfootImage("Boss1.gif"),
        new GreenfootImage("Boss2.gif"),
        new GreenfootImage("Boss3.gif"),
        new GreenfootImage("Boss4.gif"),
        new GreenfootImage("Boss5.gif"),
        new GreenfootImage("Boss6.gif"),
        new GreenfootImage("Boss7.gif"),
        new GreenfootImage("Boss8.gif"),
    };
    
    private GreenfootImage[] expolodeFrames = {
        new GreenfootImage("Explosion1.png"),
        new GreenfootImage("Explosion2.png"),
        new GreenfootImage("Explosion3.png"),
        new GreenfootImage("Explosion4.png"),
        new GreenfootImage("Explosion5.png"),
        new GreenfootImage("Explosion6.png"),
    };
    
    private int explodeframe = 0;
    private int deathTimer = 0;
    
    private boolean isDead = false;
    
    private int timer = 0;
    private int frame = 0; 

    private int health, maxHealth;
    
    public boolean isPhaseTwo = false;
    public FinalBoss()
    {
        maxHealth = 20000;
        health = maxHealth;
            
            if(isDead == false)
        {
            for (int i = 0; i < frames.length; i++) {
                frames[i].scale(170, 190);
            }
            setImage(frames[0]);
        }
        else
        {
            for (int i = 0; i < expolodeFrames.length; i++) {
                    expolodeFrames[i].scale(150, 150);
            }
            
            setImage(expolodeFrames[0]);
        }
            setImage(frames[0]);
    }
    
    public void act()
    {
        
        if (isDead) {
            animateDeath();
            return; // Don't run anything else
        }
        
        if(health <= 5000)
        {
            isPhaseTwo = true;
        }
        
        if(isPhaseTwo == true)
        {
            if (Greenfoot.getRandomNumber(1600) < 2) { // small chance
                deathRay();
            }
        }
        
        
        animateIdle();
        
        if(isPhaseTwo == true)
        {
            moveToCenter();
        }
        else
        {
            FollowPlayer();
        }
        
        ShootPlayer();
        getStatus();
        
        
    }
    
    private void moveToCenter()
    {
        if (getWorld() != null) {
            int centerX = getWorld().getWidth() / 2;
            setLocation(centerX, getY());
        }
    }
    
    private void animateIdle() {
        timer++;
        if (timer % 10 == 0) {
            frame = (frame + 1) % frames.length;
            setImage(frames[frame]);
        }
    }
    
    public void animateDeath() {
        
        if(getWorld()!=null)
        {
            deathTimer++;
            if (deathTimer % 10 == 0 && explodeframe < expolodeFrames.length) {
                setImage(expolodeFrames[explodeframe]);
                explodeframe++;
            }
            if (explodeframe >= expolodeFrames.length) {
            
                getWorld().removeObject(this);
            
            }
        }
        
    }
    
    private double velocityX = 0;

    public void FollowPlayer()
    {
        if (!getWorld().getObjects(Spaceship.class).isEmpty()) {
            Spaceship spaceship = getWorld().getObjects(Spaceship.class).get(0);

            int playerX = spaceship.getX();
            int bossX = getX();

            // Calculate difference
            int diff = playerX - bossX;

            // Accelerate toward player
            velocityX += diff * 0.01; // adjust factor for responsiveness

            // Apply friction to avoid overshooting
            velocityX *= 0.7;

            // Update position
            setLocation((int)(bossX + velocityX), getY());
        }
    }
    
    private Spaceship getSpaceship()
    {
        if(getWorld().getObjects(Spaceship.class).isEmpty())
            return null;
            return getWorld().getObjects(Spaceship.class).get(0);
    }

    public void ShootPlayer()//shoot at player at random time
    {
        if(Greenfoot.getRandomNumber(30) == 0){
            if (getWorld() == null)
            return;
            AlienBullet a = new AlienBullet();
            getWorld().addObject(a, getX(), getY());
            
            Spaceship spaceship = getSpaceship();
            if(spaceship!=null)
                a.turnTowards(spaceship.getX(), spaceship.getY());
            Greenfoot.playSound("alienBullet.mp3");    
        }
    }
    
    public double getStatus()
    {
        return (double)health/maxHealth; //stay as double
        
    }

    public void setMaxHealth(int maxHp)
    {
        maxHealth = maxHp;
    }
    public int getHealth()
    {
        return health;
    }

    public void setHealth(int health)
    {
        this.health = health;
    }
    
    public void takeDamage(int damage)
    {
        health -= damage;
        
        if(health <=0 && !isDead)
        {

            if(getWorld()!=null)
            {
                die();
            }
                
            
        }
    }
    
    public void die() {
        isDead = true;
        explodeframe = 0;
        deathTimer = 0;
    }
    
    public void deathRay()
    {
        
        
        DeathRay ray = new DeathRay(this);
        getWorld().addObject(ray, 310, 300);
    }
    
  
    

}
