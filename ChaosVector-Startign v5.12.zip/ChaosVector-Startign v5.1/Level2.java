import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Level2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Level2 extends World
{

    private int maxComets = 5;
    private int maxAliens = 3;
    private int maxPotion = 1;
    
    private boolean bossSpawned = false;
    
    /**
     * Constructor for objects of class Level2.
     * 
     */
    public Level2()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 

        for (int i = 0; i < maxComets; i++) {
            spawnComet();
        }
        
        
        prepare();
    }

    public void act()
    {
        if (getObjects(Comet.class).size() < maxComets) {
            if (Greenfoot.getRandomNumber(100) < 2) { // small chance
                spawnComet();
            }
        }
        
        if (getObjects(Comet.class).size() < maxPotion) {
            if (Greenfoot.getRandomNumber(800) < 2) { // small chance
                spawnHealthPotion();
            }
        }
        
        if (getObjects(Alien.class).size() < maxAliens) {
            if (Greenfoot.getRandomNumber(400) < 2) { // small chance
                spawnAlien();
            }
        }
        
        spawnOctoAlien();
    }

    private void spawnComet()
    {
        Comet c = new Comet();
        int x = Greenfoot.getRandomNumber(getWidth()); // random horizontal
        int y = 0; // top of the world
        addObject(c, x, y);
    }
    
    private void spawnHealthPotion()
    {
        HealthPotion h = new HealthPotion();
        int x = Greenfoot.getRandomNumber(getWidth()); // random horizontal
        int y = 0; // top of the world
        addObject(h, x, y);
    }
    
    private void spawnAlien()
    {
        if(!bossSpawned)
        {
            Alien alien = new Alien();
            addObject(alien, 400, 100);
            
            alien.setMaxHealth(400);
            alien.setHealth(400);
            
            alien.setSpeed(2);
            alien.setChargeSpeed(4);
            
            AlienHp hpBar = new AlienHp(100, 10, alien);
            addObject(hpBar, alien.getX(), alien.getY() + alien.getImage().getHeight()/2 + 5);
       
        }
        //addObject(new Alien(), getWidth()/2, 50);
        
    }
    
    private void spawnOctoAlien()
    {
        Alien alien = new Alien();
        
        if(alien.killCount == 5 && !bossSpawned)
        {
    
            OctoAlien alien2 = new OctoAlien();
            addObject(alien2, 400, 100);
            
            //alien2.setMaxHealth(3500);
            //alien2.setHealth(3500);
            
            OctoAlienHp octoHpBar = new OctoAlienHp(100, 10, alien2);
            addObject(octoHpBar, alien2.getX(), alien2.getY() + alien2.getImage().getHeight()/2 + 5);
            
            alien.killCount = 0;
            bossSpawned = true;
            Greenfoot.playSound("octopus.mp3");
        }
        
        
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Spaceship spaceship = new Spaceship();
        addObject(spaceship,293,304);
        
        HealthBar healthBar = new HealthBar(100,10,spaceship);
        addObject(healthBar, healthBar.getWidth()/2, healthBar.getHeight()/2);
    }
}
