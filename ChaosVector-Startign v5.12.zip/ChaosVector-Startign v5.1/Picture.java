import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Picture here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Picture extends Actor
{   
    public Picture(GreenfootImage myImage)
    {
        setImage(myImage); //same pic as MainLobby
        GreenfootImage image = getImage();  
        image.scale(100, 75);
        setImage(image);
    }
    /**
     * Act - do whatever the Picture wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
    }
}
