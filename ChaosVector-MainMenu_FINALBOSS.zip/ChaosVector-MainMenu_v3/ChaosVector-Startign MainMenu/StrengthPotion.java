import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class HealthPotion here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class StrengthPotion extends Actor
{
    /**
     * Act - do whatever the HealthPotion wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    private int speed;
    
    public StrengthPotion()
    {
        //this.size = size;
        this.speed = 3;
        //random rotation
        //setRotation ( Greenfoot.getRandomNumber(360));
        //scale of image
    }
    
    public void act()
    {         
        move(speed);
        setRotation(90);
        
        // if it touches the spaceship, deal damage and remove itself
        Spaceship ship = (Spaceship)getOneIntersectingObject(Spaceship.class);
        if (ship != null) {
            ship.activatePotion(); // adjust damage as needed
            getWorld().removeObject(this);
            return; // stop further processing this frame
        }

        // remove comet if it reaches bottom
        if (getY() >= getWorld().getHeight() - 1) 
        {
            getWorld().removeObject(this);
        }

    

        
    }
}
