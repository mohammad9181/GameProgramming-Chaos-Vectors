import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Level1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Level1 extends World
{

    /**
     * Constructor for objects of class Level1.
     * 
     */
    
    private int maxComets = 5;
    private int bossTimer = 0;
    
    private GreenfootSound backgroundMusic = new GreenfootSound("level1BGM.mp3");
    public Level1()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1);
        
        

        GreenfootImage bg = new GreenfootImage("BG1.png"); // adjust filename as needed
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
        
        for (int i = 0; i < maxComets; i++) {
            spawnComet();
        }
        
        prepare();
        

    }
    
    public void started()
    {
        backgroundMusic.playLoop();
    }
    
    public void stopped()
    {
        backgroundMusic.pause();
    }
    
    public void act()
    {
        if (getObjects(Comet.class).size() < maxComets) {
            if (Greenfoot.getRandomNumber(100) < 2) { // small chance
                spawnComet();
            }
        }
        
        
        
        //alien will spawn
        bossTimer++;
        if(bossTimer == 500){
            //addObject(new Alien(), getWidth()/2, 50);
            Alien alien = new Alien();
            addObject(alien, 400, 100);
            AlienHp hpBar = new AlienHp(100, 10, alien);
            addObject(hpBar, alien.getX(), alien.getY() + alien.getImage().getHeight()/2 + 5);
            
            
            Spaceship spaceship = getObjects(Spaceship.class).get(0);
            spaceship.setEnemiesSpawned(true);// for gamewin condition
        }
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Spaceship spaceship = new Spaceship();
        addObject(spaceship,297,318);

        HealthBar healthBar = new HealthBar(100,10,spaceship);
        addObject(healthBar, healthBar.getWidth()/2, healthBar.getHeight()/2);
    }
    
    private void spawnComet()
    {
        Comet c = new Comet();
        int x = Greenfoot.getRandomNumber(getWidth()); // random horizontal
        int y = 0; // top of the world
        addObject(c, x, y);
    }
}
