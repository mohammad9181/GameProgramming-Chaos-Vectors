import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class HealthBar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class AlienHp extends Alien
{
    private int width, height;
    private Alien myAlien;
    
    public AlienHp(int width, int height, Alien myAlien)
    {
        this.width = width;
        this.height = height;
        this.myAlien = myAlien;
    }
    
    public int getWidth()
    {
        return width;
    }
    
    public int getHeight()
    {
        return height;
    }
    
    /**
     * Act - do whatever the HealthBar wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        if (myAlien == null||myAlien.getWorld() == null)
        
            if(getWorld()!= null)
            {
                getWorld().removeObject(this);
                return;
            }
            // hpBar stays under alien
            int alienX = myAlien.getX();
            int alienY = myAlien.getY();
            int offsetY= myAlien.getImage().getHeight()/2+height/2+2;
            setLocation(alienX,alienY+offsetY);
        
        draw();
    }
    
    public void draw()
    {
        GreenfootImage myImage = new GreenfootImage( width, height);
        //lost health
        myImage.setColor(Color.BLACK);
        myImage.fillRect(0, 0,width, height);
        // Draw remaining health
        int healthPercentage = (int)(myAlien.getStatus() * width);
        myImage.setColor(Color.RED);
        myImage.fillRect( 0, 0, healthPercentage, height);
        
        setImage(myImage);
    }

}