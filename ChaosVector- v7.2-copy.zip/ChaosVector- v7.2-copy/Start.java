import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import greenfoot.World;

/**
 * Write a description of class Start here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Start extends Buttons
{
    public Start()
    {
        GreenfootImage image = getImage();  
        image.scale(100, 50);
        setImage(image);
    }
    /**
     * Act - do whatever the Start wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
        
        
        if (Greenfoot.mouseClicked(this)) {
             World current = getWorld(); //stop bgm in world before swithcing
            if (current instanceof MainLobby) {
                ((MainLobby) current).stopMusic();
            } 
                else if (current instanceof GameWin) {
                ((GameWin) current).stopMusic();
                } 
                else if (current instanceof Levels) {
                ((Levels) current).stopMusic();
             } 
        
            Greenfoot.setWorld(new Levels());
        }
    }
}